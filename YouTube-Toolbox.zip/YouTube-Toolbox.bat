@ECHO OFF
REM BFCPEOPTIONSTART
REM Advanced BAT to EXE Converter www.BatToExeConverter.com
REM BFCPEEXE=C:\Users\ItsKr\Music\Youtube Toolbox\YouTube-Toolbox.exe
REM BFCPEICON=C:\Users\ItsKr\Music\Youtube Toolbox\scripts\toolkit.ico
REM BFCPEICONINDEX=1
REM BFCPEEMBEDDISPLAY=0
REM BFCPEEMBEDDELETE=1
REM BFCPEADMINEXE=1
REM BFCPEINVISEXE=0
REM BFCPEVERINCLUDE=1
REM BFCPEVERVERSION=1.1.0.0
REM BFCPEVERPRODUCT=Youtube Toolkit
REM BFCPEVERDESC=Download, rename, organize YouTube music
REM BFCPEVERCOMPANY=MoreKronos Github
REM BFCPEVERCOPYRIGHT=(c) 2025 MoreKronos
REM BFCPEWINDOWCENTER=1
REM BFCPEDISABLEQE=0
REM BFCPEWINDOWHEIGHT=30
REM BFCPEWINDOWWIDTH=120
REM BFCPEWTITLE=Youtube Toolkit
REM BFCPEOPTIONEND
@echo off
setlocal enabledelayedexpansion
:: Check for admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -Command "Start-Process '%~f0' -Verb runAs"
    exit /b
)

title Youtube Toolbox
color 0B

:: --------------------------------------------------
:: Automatically get the folder where this script is running
:: --------------------------------------------------
set "base_folder=%~dp0"
set "base_folder=%base_folder:~0,-1%"
set "scripts=%base_folder%\scripts"

set "downloads_folder=%base_folder%\downloads"
if not exist "%downloads_folder%" mkdir "%downloads_folder%"

set "target_folder=%base_folder%\music_files"
if not exist "%target_folder%" mkdir "%target_folder%"

if not exist "%scripts%" mkdir "%scripts%"

set "yt_dlp_path=%base_folder%\scripts\yt-dlp\yt-dlp.exe"
set "ffmpeg_path=%base_folder%\scripts\ffmpeg\bin"
set "ffmpeg_check=%ffmpeg_path%\ffmpeg.exe"
set "sevenzip_path=%base_folder%\scripts\7zip\7z.exe"
set "dupefinder_path=%base_folder%\scripts\dupefinder\dupefinder.ps1"
set "downloads_folder_local=%USERPROFILE%\Downloads"
set "temp_folder_local=%USERPROFILE%\AppData\Local\Temp"
set "archive_file="
set "extracted_folder="

goto Welcome

:error
cls
color 0C
title Missing Dependencies
echo ==================================================
echo             Missing or Incorrect Dependencies
echo ==================================================
echo.
echo [ERROR] One or more required dependencies are missing or not correctly installed.
echo Checking if any need to be downloaded or reinstalled...
echo.

timeout /t 10 >nul

if not exist "!sevenzip_path!" (
    echo [ERROR] 7-Zip not found at "!sevenzip_path!"
    goto download7zip
)

if not exist "!yt_dlp_path!" (
    echo [ERROR] yt-dlp.exe not found at "!yt_dlp_path!"
    goto downloadytdlp
)

if not exist "!ffmpeg_check!" (
    echo [ERROR] ffmpeg not found at "!ffmpeg_check!"
    goto downloadffmpeg
)

if not exist "!dupefinder_path!" (
    echo [ERROR] Dupefinder not found at "!dupefinder_path!"
    goto downloaddupefinder
)

:check

echo Checking dependencies...

if not exist "%sevenzip_path%" (
    echo Installing 7-Zip...
    goto download7zip
)

if not exist "%yt_dlp_path%" (
    echo Installing yt-dlp...
    goto downloadytdlp
)

if not exist "%ffmpeg_check%" (
    echo Installing ffmpeg...
    goto downloadffmpeg
)

if not exist "%dupefinder_path%" (
    echo Installing dupefinder...
    goto downloaddupefinder
)

echo All dependencies OK.
goto Welcome

"%yt_dlp_path%" -U
if %errorlevel% neq 0 (
    echo [ERROR] yt-dlp update failed.
) else (
    echo yt-dlp updated successfully.
)

if exist "%temp_folder_local%\myfiles" (
    rd /s /q "%temp_folder_local%\myfiles"
)

goto Welcome

:download7zip
cls
title 7-Zip Downloader
color 0B
echo ==================================================
echo                   7-Zip Downloader
echo ==================================================
echo 7-Zip archive download is required to run this program.
echo.

:: SET THESE FIRST — before user input!
set "sevenzipDownloadURL=https://github.com/MoreKronos/7-zip-portable/releases/download/Portable/7-zip-portable.zip"
set "sevenzipDownloadPath=%USERPROFILE%\Downloads\7-zip-portable.zip"

set /p sevenzip_dl=Download Required^^! (Y/N): 

if /i "%sevenzip_dl%"=="Y" (
    echo.
    echo Downloading 7-Zip Please Wait...
    echo.

	powershell -Command "Invoke-WebRequest -Uri '%sevenzipDownloadURL%' -OutFile '%sevenzipDownloadPath%' -UseBasicParsing -Verbose"

    if not exist "%sevenzipDownloadPath%" (
        echo [ERROR] Download failed or file not found.
        timeout /t 3 >nul
        goto check
    )

    set "zip_file=%sevenzipDownloadPath%"
    set "extract_temp=%base_folder%\downloads\7zip_temp"

    if exist "!extract_temp!" rmdir /s /q "!extract_temp!"
    mkdir "!extract_temp!"

    echo Extracting 7-Zip archive...
    powershell -Command "Expand-Archive -Path \"!zip_file!\" -DestinationPath \"!extract_temp!\" -Force"

    if not exist "!base_folder!\scripts\7zip" mkdir "!base_folder!\scripts\7zip"

    echo Copying files...
    powershell -Command "Copy-Item -Path \"!extract_temp!\*\" -Destination \"!base_folder!\scripts\7zip\" -Recurse -Force"

    if not exist "!base_folder!\scripts\7zip\7z.exe" (
        echo ERROR: Extraction failed or 7z.exe missing.
        timeout /t 3 >nul
        goto check
    )

    echo Cleaning up...
    del /f /q "!zip_file!"
    rmdir /s /q "!extract_temp!"

    echo.
    echo 7-Zip successfully installed!
    timeout /t 2 >nul
    goto check

) else if /i "%sevenzip_dl%"=="N" (
    echo Please type Y to download.
    timeout /t 2 >nul
    goto check
) else (
    echo Invalid input. Please enter Y or N.
    timeout /t 2 >nul
    goto check
)

:downloadytdlp
cls
title yt-dlp Downloader
color 0B
echo ==================================================
echo                  yt-dlp Downloader
echo ==================================================
echo yt-dlp archive download is required to run this program.
echo.

:: Set these first
set "ytdlpDownloadURL=https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_win.zip"
set "ytdlpDownloadPath=%USERPROFILE%\Downloads\yt-dlp_win.zip"

set /p ytdlp_dl=Download Required^^! (Y/N): 

if /i "%ytdlp_dl%"=="Y" (
    echo.
    echo Downloading yt-dlp Please Wait...
    echo.

	powershell -Command "Invoke-WebRequest -Uri '%ytdlpDownloadURL%' -OutFile '%ytdlpDownloadPath%' -UseBasicParsing -Verbose"
    if not exist "%ytdlpDownloadPath%" (
        echo [ERROR] Download failed or file not found.
        timeout /t 3 >nul
        goto check
    )

    set "zip_file=%ytdlpDownloadPath%"
    set "extract_temp=%base_folder%\downloads\yt-dlp_temp"

    if exist "!extract_temp!" rmdir /s /q "!extract_temp!"
    mkdir "!extract_temp!"

    echo Extracting yt-dlp archive...
    powershell -Command "Expand-Archive -Path \"!zip_file!\" -DestinationPath \"!extract_temp!\" -Force"

    if not exist "!base_folder!\scripts\yt-dlp" mkdir "!base_folder!\scripts\yt-dlp"

    echo Copying files from extracted folder...
    powershell -Command "Copy-Item -Path \"!extract_temp!\*\" -Destination \"!base_folder!\scripts\yt-dlp\" -Recurse -Force"

    if not exist "!base_folder!\scripts\yt-dlp\yt-dlp.exe" (
        echo ERROR: Extraction failed or yt-dlp.exe not found.
        timeout /t 5 >nul
        goto check
    )

    echo Cleaning up...
    del /f /q "!zip_file!"
    rmdir /s /q "!extract_temp!"

    echo.
    echo yt-dlp successfully installed to: !base_folder!\scripts\yt-dlp
    timeout /t 2 >nul
    goto check

) else if /i "%ytdlp_dl%"=="N" (
    echo Please type Y to download.
    timeout /t 2 >nul
    goto check
) else (
    echo Invalid input. Please enter Y or N.
    timeout /t 2 >nul
    goto check
)

:downloadffmpeg
cls
title FFMPEG Downloader
color 0B
echo ==================================================
echo                 FFMPEG Downloader
echo ==================================================
echo FFMPEG is required to run this program
echo.

:: Set URLs and paths before user input
set "ffmpegDownloadURL=https://www.gyan.dev/ffmpeg/builds/ffmpeg-git-full.7z"
set "ffmpegDownloadPath=%USERPROFILE%\Downloads\ffmpeg-git-full.7z"

set /p ffmpeg_dl=Download Required^^! (Y/N): 

if /i "%ffmpeg_dl%"=="Y" (
    echo.
    echo Downloading FFMPEG Please Wait...
    echo.

	powershell -Command "Invoke-WebRequest -Uri '%ffmpegDownloadURL%' -OutFile '%ffmpegDownloadPath%' -UseBasicParsing -Verbose"

    if not exist "%ffmpegDownloadPath%" (
        echo [ERROR] Download failed or file not found.
        timeout /t 3 >nul
        goto check
    )

    set "archive_file=%ffmpegDownloadPath%"
    set "extract_temp=%base_folder%\downloads\ffmpeg_temp"

    if exist "!extract_temp!" rmdir /s /q "!extract_temp!"
    mkdir "!extract_temp!"

    echo Extracting "!archive_file!" to "!extract_temp!"...
    "!sevenzip_path!" x "!archive_file!" -o"!extract_temp!" -y

    if errorlevel 1 (
        echo Extraction failed with error code !errorlevel!.
        timeout /t 5 >nul
        goto check
    )

    :: Detect the extracted folder name dynamically (assuming only one folder extracted)
    set "extracted_folder="
    for /d %%D in ("!extract_temp!\*") do set "extracted_folder=%%D"

    if not defined extracted_folder (
        echo ERROR: Could not find extracted ffmpeg folder.
        timeout /t 5 >nul
        goto check
    )

    if not exist "!base_folder!\scripts\ffmpeg" mkdir "!base_folder!\scripts\ffmpeg"

    echo Copying bin folder from "!extracted_folder!\bin" to "!base_folder!\scripts\ffmpeg\bin"...
    xcopy /e /i /y "!extracted_folder!\bin" "!base_folder!\scripts\ffmpeg\bin" >nul

    if not exist "!base_folder!\scripts\ffmpeg\bin\ffmpeg.exe" (
        echo ERROR: Failed to copy ffmpeg binaries.
        timeout /t 5 >nul
        goto check
    )

    echo Cleaning up...
    rmdir /s /q "!extract_temp!"
    del /f /q "!archive_file!"

    echo.
    echo FFmpeg successfully installed!
    timeout /t 2 >nul
    goto check

) else if /i "%ffmpeg_dl%"=="N" (
    echo Please type Y to download.
    timeout /t 2 >nul
    goto check
) else (
    echo Invalid input. Please enter Y or N.
    timeout /t 2 >nul
    goto check
)

:downloaddupefinder
cls
title Dupefinder Downloader
color 0B
echo ==================================================
echo               Dupefinder Downloader
echo ==================================================
echo Dupefinder archive download is required to run this program.
echo.

:: Set URLs and paths before user input
set "dfDownloadURL=https://github.com/MoreKronos/Dupefinder/releases/download/Script/dupefinder.zip"
set "dfDownloadPath=%USERPROFILE%\Downloads\dupefinder.zip"

set /p dupe_dl=Download Required^^! (Y/N): 

if /i "%dupe_dl%"=="Y" (
    echo.
    echo Downloading Dupefinder Please Wait...
    echo.

	powershell -Command "Invoke-WebRequest -Uri '%dfDownloadURL%' -OutFile '%dfDownloadPath%' -UseBasicParsing -Verbose"

    if not exist "%dfDownloadPath%" (
        echo [ERROR] Download failed or file not found.
        timeout /t 3 >nul
        exit /b 1
    )

    set "zip_file=%dfDownloadPath%"
    set "extract_temp=%base_folder%\downloads\dupefinder_temp"

    if exist "!extract_temp!" rmdir /s /q "!extract_temp!"
    mkdir "!extract_temp!"

    echo Extracting Dupefinder archive...
    powershell -Command "Expand-Archive -Path \"!zip_file!\" -DestinationPath \"!extract_temp!\" -Force"

    if not exist "%base_folder%\scripts\dupefinder" mkdir "%base_folder%\scripts\dupefinder"

    echo Copying Dupefinder files from extracted folder...
    xcopy /E /I /Y "!extract_temp!\*" "%base_folder%\scripts\dupefinder\" >nul

    if not exist "%base_folder%\scripts\dupefinder\dupefinder.ps1" (
    echo ERROR: Extraction failed or dupefinder.ps1 not found.
    timeout /t 5 >nul
    goto check
    )

    echo Cleaning up...
    del /f /q "!zip_file!"
    rmdir /s /q "!extract_temp!"

    echo.
    echo Dupefinder successfully installed to: %base_folder%\scripts\dupefinder
    timeout /t 2 >nul
    goto check

) else if /i "%dupe_dl%"=="N" (
    echo Please type Y to download.
    timeout /t 2 >nul
    endlocal
    goto check
) else (
    echo Invalid input. Please enter Y or N.
    timeout /t 2 >nul
    goto check
)

:WaitForFilePattern
setlocal enabledelayedexpansion

set "folder=%~1"
set "pattern=%~2"

if "%folder%"=="" (
    echo [ERROR] WaitForFilePattern: Folder path missing.
    timeout /t 3 >nul
    endlocal & exit /b 1
)

if "%pattern%"=="" (
    echo [ERROR] WaitForFilePattern: File pattern missing.
    timeout /t 3 >nul
    endlocal & exit /b 1
)

set "lastSize=-1"
set /a stableCount=0
set /a elapsed=0
set /a maxTimeout=50000

:WaitLoop
set "filePath="
set "fileExt="
set "currentSize=0"

for %%F in ("%folder%\%pattern%") do (
    set "filePath=%%~fF"
    set "fileExt=%%~xF"
)

if "!filePath!"=="" (
    timeout /t 3 >nul
    set /a elapsed+=3
    if !elapsed! geq !maxTimeout! (
        echo [ERROR] Timeout: No matching file found.
        endlocal & exit /b 1
    )
    goto WaitLoop
)

if /i "!fileExt!"==".crdownload" (
    timeout /t 3 >nul
    set /a elapsed+=3
    goto WaitLoop
)

for %%I in ("!filePath!") do set "currentSize=%%~zI"

if !currentSize! leq 0 (
    timeout /t 3 >nul
    set /a elapsed+=3
    goto WaitLoop
)

if "!currentSize!"=="!lastSize!" (
    set /a stableCount+=1
) else (
    set "lastSize=!currentSize!"
    set /a stableCount=0
)

if !stableCount! geq 6 (
    echo [INFO] File is stable: !filePath!
    endlocal & exit /b 0
)

if !elapsed! geq !maxTimeout! (
    echo [ERROR] Timeout: File never stabilized.
    endlocal & exit /b 1
)

timeout /t 3 >nul
set /a elapsed+=3
goto WaitLoop

:Welcome
cls
title Welcome
color 0B
echo ==================================================
echo                      Welcome %USERNAME%
echo ==================================================
echo.
timeout /t 3 >nul

if not exist "!sevenzip_path!" (
    echo [ERROR] 7-Zip not found at "!sevenzip_path!"
    goto ERROR
)

if not exist "!yt_dlp_path!" (
    echo [ERROR] yt-dlp.exe not found at "!yt_dlp_path!"
    goto ERROR
)

if not exist "!ffmpeg_check!" (
    echo [ERROR] ffmpeg not found at "!ffmpeg_check!"
    goto ERROR
)

if not exist "!dupefinder_path!" (
    echo [ERROR] Dupefinder not found at "!dupefinder_path!"
    goto ERROR
)

"%yt_dlp_path%" -U
if %errorlevel% neq 0 (
    echo [ERROR] yt-dlp update failed.
) else (
    echo yt-dlp updated successfully.
)

if exist "%temp_folder_local%\myfiles" (
    rd /s /q "%temp_folder_local%\myfiles"
)

goto YoutubeToolbox

:YoutubeToolbox
title Youtube Toolbox
color 0B
cls
echo ==================================================
echo             Welcome to YouTube Toolbox
echo ==================================================
echo.
echo This tool can help you:
echo    [1] Download Music from YouTube
echo    [2] Organize, Rename, and Remove Duplicate MP3 Files, (Recommended to run after downloading)
echo    [3] Open Music folder
echo    [4] Exit the Toolbox
echo.

set /p "choice=Please enter your choice (1-4): "

if "!choice!"=="1" goto Download
if "!choice!"=="2" goto Detect
if "!choice!"=="3" (
    start "" "%target_folder%"
    goto YoutubeToolbox
)
if /i "!choice!"=="4" (
    title Exiting - YouTube Toolbox
    cls
    echo ==================================================
    echo              Operation Cancelled by %USERNAME%
    echo ==================================================
    echo.
    for /L %%x in (5,-1,1) do (
        cls
        echo ==================================================
        echo              Operation Cancelled by %USERNAME%
        echo ==================================================
        echo.
        echo Exiting in %%x second%%x%%...
        timeout /t 1 >nul
    )
    cls
    echo ==================================================
    echo                  Goodbye, %USERNAME%
    echo ==================================================
    timeout /t 1 >nul
    exit /b
)

echo.
echo Invalid input. Please select a valid option (1, 2, or 3).
echo.
timeout /t 5 >nul
goto YoutubeToolbox
set "isPlaylist=0"

:Download
cls
setlocal enabledelayedexpansion

echo ==================================================
echo YouTube Music Downloader
echo ==================================================
echo.
echo Supports:
echo - Single songs
echo - Podcasts
echo - Full music playlists
echo.
echo Type "exit" to return to the main menu.
echo ==================================================
echo.

set "yt_url="
set /p yt_url=Enter YouTube video or playlist URL: 

:: empty check
if not defined yt_url goto BadURL

:: escape ampersands (CRITICAL FIX for &si= etc.)
set "yt_url=!yt_url:^&=^&!"

:: trim leading spaces safely
for /f "tokens=* delims= " %%A in ("!yt_url!") do set "yt_url=%%A"

:: exit option
if /i "!yt_url!"=="exit" goto YoutubeToolbox

:: must contain youtube
echo(!yt_url! | findstr /i "youtu" >nul
if errorlevel 1 goto BadURL

:: block shorts
echo(!yt_url! | findstr /i "/shorts/" >nul
if not errorlevel 1 goto BadURL

:: playlist detection
set "isPlaylist=0"
echo(!yt_url! | findstr /i "list=" >nul
if not errorlevel 1 set "isPlaylist=1"


cls
echo ==================================================
echo Downloading and converting audio...
echo ==================================================
echo.

if "%isPlaylist%"=="1" (
    echo [MODE] Playlist download detected
    echo.

"%yt_dlp_path%" ^
    --no-warnings ^
    --yes-playlist ^
    --extract-audio ^
    --audio-format mp3 ^
    --audio-quality 0 ^
    --embed-thumbnail ^
	--add-metadata ^
    --ffmpeg-location "%ffmpeg_path%" ^
    --output "%downloads_folder%\%%(autonumber)06d.%%(ext)s" ^
    "%yt_url%"

) else (
    echo [MODE] Single download detected
    echo.

"%yt_dlp_path%" ^
    --no-warnings ^
    --extract-audio ^
    --audio-format mp3 ^
    --audio-quality 0 ^
    --embed-thumbnail ^
	--add-metadata ^
    --ffmpeg-location "%ffmpeg_path%" ^
    --output "%downloads_folder%\%%(autonumber)06d.%%(ext)s" ^
    "%yt_url%"
)


echo.
echo ==================================================
echo             Download Complete!
echo ==================================================
echo.

cls
echo.
echo ==================================================
echo               Renaming Files!
echo ==================================================
echo.
echo Renaming downloaded MP3 files to random numbers...

pushd "%downloads_folder%"
setlocal enabledelayedexpansion

for %%F in (*.mp3) do (

    :genRand
    set /a randNum=!random! * 32768 + !random!
    set /a randNum=!randNum! %% 900000 + 100000

    if exist "!randNum!.mp3" goto genRand

    ren "%%F" "!randNum!.mp3"
    echo Renamed "%%F" to "!randNum!.mp3"
)

endlocal
popd1

echo.
echo ==================================================
echo               Rename Complete!
echo ==================================================
echo.
timeout /t 2 >nul
goto YoutubeToolbox

:BadURL
echo.
echo [ERROR] Invalid or incomplete YouTube URL.
echo Please paste a FULL video or playlist link.
timeout /t 2 >nul
goto Download

:Detect
title Duplicate Detection
cls
echo ==================================================
echo         Detecting and Handling Duplicate Songs
echo ==================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0scripts\dupefinder\dupefinder.ps1'"

echo.
echo Duplicate detection complete.
timeout /t 3 >nul

goto organize

:Organize
setlocal enabledelayedexpansion

cd /d "%target_folder%"

set max=0
set /a count=1

timeout /t 5 >nul
title Organizing and Renaming Files...
for /L %%i in (1,1,1) do (	
    cls
    echo.
    echo --------------------------------------------------
    echo          Organizing and Renaming Files...
    echo --------------------------------------------------
    echo.
    set /a count=1
    for %%F in (*.mp3) do (
        set "filename=%%~nF"
        echo !filename! | findstr /r "^[0-9][0-9][0-9][0-9][0-9]$" >nul
        if errorlevel 1 (
            set "num=00000!count!"
            set "num=!num:~-5!"
            echo - Renaming "%%F" to "!num!%%~xF"
            ren "%%F" "!num!%%~xF"
            set /a count+=1
        ) else (
            echo - Skipping already numbered file: %%F
        )
    )
)

echo.
title complete.
echo - File numbering complete.
echo.

timeout /t 3 >nul

echo ==================================================
echo  All done! Your music_files folder is organized.
echo ==================================================
echo.
goto YoutubeToolbox